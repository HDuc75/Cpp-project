package com.example.Project_KT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectKtApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectKtApplication.class, args);
	}

}
