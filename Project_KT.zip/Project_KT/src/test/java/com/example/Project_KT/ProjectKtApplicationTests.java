package com.example.Project_KT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectKtApplicationTests {

	@Test
	void contextLoads() {
	}

}
