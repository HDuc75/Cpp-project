package fa.training.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DBUtils {
    private static final Logger logger = LoggerFactory.getLogger(DBUtils.class);

    // Cấu hình kết nối cơ sở dữ liệu
    private static final String URL = "jdbc:mysql://localhost:3306/quanlysuckhoe?useSSL=false&serverTimezone=UTC";// Địa chỉ cơ sở dữ liệu
    private static final String USERNAME = "root"; // Tên người dùng
    private static final String PASSWORD = ""; // Mật khẩu

    // Phương thức để lấy kết nối
    public static Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Tải driver JDBC
            Properties info = new Properties();
            info.put("user", USERNAME); // Tên người dùng
            info.put("password", PASSWORD); // Mật khẩu
            
            connection = DriverManager.getConnection(URL, info); // Kết nối với cơ sở dữ liệu
            logger.info("Kết nối cơ sở dữ liệu thành công!");
        } catch (ClassNotFoundException e) {
            logger.error("Không tìm thấy driver JDBC: {}", e.getMessage());
        } catch (SQLException e) {
            logger.error("Kết nối cơ sở dữ liệu thất bại: {}", e.getMessage());
        }
        return connection;
    }


    // Phương thức để đóng kết nối (không cần thiết khi sử dụng try-with-resources)
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close(); // Đóng kết nối
                logger.info("Đóng kết nối cơ sở dữ liệu thành công!"); // Ghi thông báo đóng kết nối thành công
            } catch (SQLException e) {
                logger.error("Lỗi khi đóng kết nối: {}", e.getMessage()); // Thông báo lỗi nếu đóng không thành công
            }
        }
    }
}
