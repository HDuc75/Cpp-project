package fa.training.utils;

public class Constants {
	public static final String REGISTER_FAIL_MESSAGE = "Registration failed. Please try again.";
	public static final String ADD_EMPLOYEE_FAIL_MESSAGE = "AddEmployee failed. Please try again.";
}
