package fa.training.entities;

public class CongDan {
	private String soCCCD;
	private String hoTen;
	private int tuoi;
	private String email;
	
	public CongDan(String soCCCD, String hoTen, int tuoi, String email) {
	    this.soCCCD = soCCCD;
	    this.hoTen = hoTen;
	    this.tuoi = tuoi;
	    this.email = email; 
	}
	
	public CongDan() {};
	
	public String getsoCCCD() {
        return soCCCD;
    }

    public void setCCCD(String soCCCD) {
        this.soCCCD = soCCCD;
    }
    
    public String gethoTen() {
        return hoTen;
    }

    public void sethoTen(String hoTen) {
        this.hoTen = hoTen;
    }
    
    
    public int gettuoi() {
        return tuoi;
    }

    public void settuoi(int tuoi) {
        this.tuoi = tuoi;
    }
    
    public String getemail() {
        return email;
    }

    public void setemail(String email) {
        this.email = email;
    }
}
